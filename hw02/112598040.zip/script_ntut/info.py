TOTAL_PAGES = 15
# personal information below
ID = "112598040"  # student ID here
NAME = "王麗雅"  # name here
NUMBER = 0  # number here
